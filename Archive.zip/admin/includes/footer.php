<footer>
    <div class="copyright">
        copyright &copy; 2022 All rights reserved | powered by: <a href="">Fourtech</a>
    </div>
</footer>